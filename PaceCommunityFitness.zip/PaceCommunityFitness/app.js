import React from 'react';
import Navigation from './app/Navigation'; // Ensure the path matches where Navigation.js is located

export default function App() {
  return <Navigation />;
}
